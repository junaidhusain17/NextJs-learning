import React from 'react'
import { Box, Container, Typography, Link, Button } from '@mui/material'

function Footer() {
    return (
        <Box p={6} marginTop={5} bgcolor={'#040000'}>
            <Container>
                <Typography color="GrayText" align="center">
                    {"Pixako Technology (Pvt.)Ltd."}
                </Typography>
                <Typography align='center' color="GrayText">
                    {"Copyright © "}
                    <Link component={Button} to="#">
                        Link
                    </Link>
                </Typography>
            </Container>
        </Box>
    )
}

export default Footer