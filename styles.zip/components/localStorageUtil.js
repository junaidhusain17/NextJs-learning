export const getContactData = () => {
  const contactsData = JSON.parse(localStorage.getItem("contactData")) || [];
  return contactsData;
};
export const setContactData = (data) => {
  localStorage.setItem("contactData", JSON.stringify(data));
};
