import React, { useState, useEffect } from "react";
import { useRouter } from "next/router";
import { useForm, Controller } from "react-hook-form";
import { yupResolver } from "@hookform/resolvers/yup";
import {
    Box,
    Grid,
    TextField,
    Typography,
    Button,
    RadioGroup,
    FormControlLabel,
    Checkbox,
    Radio,
    Select,
    MenuItem,
    Container,
    Paper,
    FormControl,
    InputLabel,
    FormHelperText,
} from "@mui/material";
import formSchema from "../validations/FormValidation";
import SnackBar from "./SnackBar";
import { getContactData, setContactData } from "./LocalStorageUtil";

function ContactForm() {
    const router = useRouter();

    const { id } = router.query;

    const {
        register,
        handleSubmit,
        reset,
        control,
        setValue,
        formState: { errors },
    } = useForm({
        resolver: yupResolver(formSchema),
        defaultValues: {
            // Set default values
            status: "enable",
            country: "default",
            userType: "",
            firstName: "",
            lastName: "",
            email: "",
            contactNo: "",
            account: "",
            company: "",
            confirmation: false,
            subject: "",


        },
    });

    // custom hook for managing the snackbar state and logic
    const [snackbar, setSnackbar] = useState({
        open: false,
        message: "",
        severity: "success",
    });

    // get data from localStorage and populate the form, if data not found redirect to contact page
    useEffect(() => {
        const contactsData = getContactData();
        const contact = contactsData[id - 1];

        if (contact) {
            // Loop through the keys of contactData and set the form values using setValue
            Object.keys(contact).forEach((key) => {
                setValue(key, contact[key]);
            });
        } else {
            router.push(`/contact`);
            reset();
        }
    }, [id, setValue]);

    // onSubmit function
    const onSubmit = (data) => {
        let message = "Contact created successfully";
        try {
            const existingContactData = getContactData();
            if (id) {
                existingContactData[id - 1] = data;
                message = "Contact Updated Successfully";
            } else {
                existingContactData.push(data);
            }
            setContactData(existingContactData);
            reset();

            setSnackbar({
                open: true,
                message: message,
                severity: "success",
            });

            setTimeout(() => {
                router.push(`/contactListing`);
            }, 1000);
        } catch (error) {
            setSnackbar({
                open: true,
                message: "An error occurred while saving the contact data",
                severity: "error",
            });
        }
    };


    // handleReset function for form reset
    const handleReset = () => {
        //resetting the form
        reset();
    };

    // for snackBar close
    const handleSnackbarClose = (event, action) => {
        if (action === "clickaway") {
            return;
        }
        setSnackbar({
            open: false,
            message: "",
            severity: "success",
        });
    };

    return (
        <Container>
            <Paper elevation={3}>
                <Box sx={{ mt: 8, p: 2 }}>
                    <Typography variant="h4" align="center" margin={3}>
                        CONTACT FORM
                    </Typography>
                    <form
                        id="contact-form"
                        onSubmit={handleSubmit(onSubmit)}
                        onReset={handleReset}
                        method="POST"
                    >
                        <Grid container spacing={2}>
                            <Grid item xs={12} md={6}>
                                <InputLabel htmlFor="firstName" className="required">
                                    First Name
                                </InputLabel>
                                <TextField
                                    name="firstName"
                                    id="firstName"
                                    placeholder="first name"
                                    fullWidth
                                    margin="normal"
                                    helperText={errors?.firstName?.message}
                                    error={Boolean(errors?.firstName)}
                                    {...register("firstName")}
                                />
                            </Grid>

                            <Grid item xs={12} md={6}>
                                <InputLabel htmlFor="lastName" className="required">
                                    Last Name
                                </InputLabel>
                                <TextField
                                    name="lastName"
                                    id="lastName"
                                    placeholder="last name"
                                    fullWidth
                                    margin="normal"
                                    helperText={errors?.lastName?.message}
                                    error={Boolean(errors?.lastName)}
                                    {...register("lastName")}
                                />
                            </Grid>

                            <Grid item xs={12} md={6}>
                                <InputLabel htmlFor="email" className="required">
                                    Email
                                </InputLabel>
                                <TextField
                                    name="email"
                                    id="email"
                                    variant="outlined"
                                    placeholder="example@gmail.com"
                                    fullWidth
                                    margin="normal"
                                    helperText={errors?.email?.message}
                                    error={Boolean(errors?.email)}
                                    {...register("email")}
                                />
                            </Grid>

                            <Grid item xs={12} md={6}>
                                <InputLabel htmlFor="contactNo" className="required">
                                    Contact No
                                </InputLabel>
                                <TextField
                                    name="contactNo"
                                    id="contactNo"
                                    variant="outlined"
                                    placeholder="92..........."
                                    fullWidth
                                    margin="normal"
                                    helperText={errors?.contactNo?.message}
                                    error={Boolean(errors?.contactNo)}
                                    {...register("contactNo")}
                                />
                            </Grid>

                            <Grid item xs={12} md={6}>
                                <InputLabel htmlFor="account" className="required">
                                    Account
                                </InputLabel>
                                <TextField
                                    name="account"
                                    id="account"
                                    variant="outlined"
                                    placeholder="PK54 7647 ......"
                                    fullWidth
                                    margin="normal"
                                    helperText={errors?.account?.message}
                                    error={Boolean(errors?.account)}
                                    {...register("account")}
                                />
                            </Grid>

                            <Grid item xs={12} md={6}>
                                <InputLabel htmlFor="company" className="required">
                                    Company
                                </InputLabel>
                                <TextField
                                    name="company"
                                    id="company"
                                    variant="outlined"
                                    placeholder="Pixako (Pvt).Ltd"
                                    fullWidth
                                    margin="normal"
                                    helperText={errors?.company?.message}
                                    error={Boolean(errors?.company)}
                                    {...register("company")}
                                />
                            </Grid>

                            <Grid item xs={6} md={6} className="status">
                                <Typography className="Required">Status:</Typography>
                                <Controller
                                    name="status"
                                    control={control}
                                    render={({ field }) => (
                                        <RadioGroup row {...field}>
                                            <FormControlLabel
                                                value="enable"
                                                control={<Radio color="success" />}
                                                label="Enable"
                                            />
                                            <FormControlLabel
                                                value="disable"
                                                control={<Radio color="error" />}
                                                label="Disabled"
                                            />
                                        </RadioGroup>
                                    )}
                                />
                            </Grid>

                            <Grid item xs={12} md={6}>
                                <InputLabel className="required">Country</InputLabel>
                                <Controller
                                    name="country"
                                    control={control}
                                    render={({ field }) => (
                                        <>
                                            <FormControl fullWidth>
                                                <Select
                                                    id="country"
                                                    name="country"
                                                    value={field.value}
                                                    error={Boolean(errors?.country)}
                                                    onChange={(e) => field.onChange(e.target.value)}
                                                >
                                                    <MenuItem value="default" disabled>
                                                        Select your Country
                                                    </MenuItem>
                                                    <MenuItem value="pakistan">Pakistan</MenuItem>
                                                    <MenuItem value="india">India</MenuItem>
                                                    <MenuItem value="australia">Australia</MenuItem>
                                                    <MenuItem value="US">United State</MenuItem>
                                                    <MenuItem value="UAE">United Arab Emirates</MenuItem>
                                                </Select>
                                            </FormControl>
                                            {errors.country && (
                                                <FormHelperText error>
                                                    {errors.country.message}
                                                </FormHelperText>
                                            )}
                                        </>
                                    )}
                                />
                            </Grid>

                            <Grid item xs={12} md={12}>
                                <Typography>Subject:</Typography>
                                <InputLabel htmlFor="subject"></InputLabel>
                                <TextField
                                    name="subject"
                                    id="subject"
                                    variant="outlined"
                                    fullWidth
                                    placeholder="Message......."
                                    margin="normal"
                                    multiline
                                    rows={5}
                                    {...register("subject")}
                                />
                                <Controller
                                    name="userType"
                                    control={control}
                                    render={({ field }) => (
                                        <RadioGroup row {...field}>
                                            <FormControlLabel
                                                value="Feedback"
                                                control={<Radio />}
                                                label="Feedback"
                                            />
                                            <FormControlLabel
                                                value="Support"
                                                control={<Radio />}
                                                label="Support"
                                            />
                                            <FormControlLabel
                                                value="Inquiry"
                                                control={<Radio />}
                                                label="Inquiry"
                                            />
                                        </RadioGroup>
                                    )}
                                />
                            </Grid>

                            <Grid item xs={6} md={6}>
                                <Box className="check">
                                    <Controller
                                        name="confirmation"
                                        control={control}
                                        render={({ field }) => (
                                            <Checkbox
                                                {...field}
                                                color="success"
                                                id="confirmation"
                                                checked={field.value}
                                            />
                                        )}
                                    />

                                    <InputLabel
                                        htmlFor="confirmation"
                                        sx={{ mt: "8px" }}
                                        className="required"
                                    >
                                        I am not a robot
                                    </InputLabel>
                                </Box>

                                <FormHelperText error>
                                    {errors?.confirmation?.message}
                                </FormHelperText>
                            </Grid>


                            <Grid item xs={12} md={12} className="buttons">
                                <Button
                                    type="reset"
                                    name="clear"
                                    id="clear"
                                    onClick={handleReset}
                                    variant="contained"
                                    color="error"
                                    size="large"
                                    sx={{ mt: 2, marginRight: 1 }}
                                >
                                    Clear
                                </Button>
                                <Button
                                    type="submit"
                                    name="submit"
                                    id="submit"
                                    variant="contained"
                                    size="large"
                                    sx={{ mt: 2 }}
                                >
                                    {id ? "Update" : "Submit"}
                                </Button>
                            </Grid>
                        </Grid>
                    </form>
                    <SnackBar
                        open={snackbar.open}
                        message={snackbar.message}
                        onClose={handleSnackbarClose}
                        severity={snackbar.severity}
                    />
                </Box>
            </Paper>
        </Container>
    );
}

export default ContactForm;
