import React, { useState, useEffect } from "react";
import { useRouter } from "next/router";
import {
  Typography,
  Button,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  IconButton,
  Box,
} from "@mui/material";
import { DataGrid } from "@mui/x-data-grid";
import DeleteIcon from "@mui/icons-material/Delete";
import EditIcon from "@mui/icons-material/Edit";
import SnackBar from "./SnackBar";
import { getContactData, setContactData } from "./LocalStorageUtil";

const Listing = () => {
  const [rows, setRows] = useState([]);
  const router = useRouter();

  //dialog visibility and delete id
  const [dialog, setDialog] = useState({
    open: false,
    deleteId: null,
  });

  // snackbar visibility
  const [snackbar, setSnackbar] = useState({
    open: false,
    message: "",
    severity: "success",
  });

  const handleEdit = (id) => {
    router.push(`/contact/` + id);
  };

  const handleDelete = (id) => {
    // Store the ID in the state and open the dialog
    setDialog({
      open: true,
      deleteId: id,
    });
  };

  const handleCancelDelete = () => {
    setDialog({
      open: false,
      deleteId: null,
    });
  };

  const handleConfirmDelete = () => {
    setDialog({
      open: false,
      deleteId: null,
    });

    //delete logic
    const updatedRows = rows.filter((row) => row.id !== dialog.deleteId);
    const updatedRowsWithIds = updatedRows.map((row, index) => ({
      ...row,
      id: index + 1,
    }));

    setRows(updatedRowsWithIds);

    // we are using the utility function to update localStorage
    setContactData(updatedRowsWithIds);


    // Show Snackbar message after deletion
    setSnackbar({
      open: true,
      message: "Record deleted successfully.",
      severity: "success",
    });
  };

  const handleCloseSnackbar = () => {
    setSnackbar({
      open: false,
      message: "",
      severity: "success",
    });
  };

  // retrieve the data from localStorage
  useEffect(() => {
    const storedRows = getContactData();

    const rowsWithIds = storedRows.map((row, index) => ({
      id: index + 1,
      ...row,
    }));

    setRows(rowsWithIds);
  }, []);

  const columns = [
    { field: "id", headerName: "ID", width: 70 },
    { field: "firstName", headerName: "First Name", width: 95 },
    { field: "lastName", headerName: "Last Name", width: 95 },
    { field: "email", headerName: "Email", width: 180 },
    { field: "contactNo", headerName: "Contact Number", width: 150 },
    { field: "account", headerName: "Account", width: 150 },
    { field: "company", headerName: "Company", width: 130 },
    { field: "status", headerName: "Status", width: 90 },
    { field: "country", headerName: "Country", width: 130 },
    { field: "subject", headerName: "Subject", width: 200 },
    { field: "userType", headerName: "User Type", width: 100 },
    {
      field: "action",
      headerName: "Actions",
      width: 120,
      renderCell: ({ row }) => {
        const { id } = row;
        return (
          <>
            <IconButton
              variant="contained"
              sx={{ marginRight: 1 }}
              color="primary"
              onClick={() => handleEdit(id)}
            >
              <EditIcon />
            </IconButton>
            <IconButton
              variant="contained"
              color="error"
              onClick={() => handleDelete(id)}
            >
              <DeleteIcon />
            </IconButton>
          </>
        );
      },
    }
  ];

  return (
    <>
      <Typography variant="h4" align="center" margin={5}>
        Contacts Listing
      </Typography>
      <Box height={400}>
        <DataGrid
          rows={rows}
          columns={columns}
          initialState={{
            pagination: {
              paginationModel: { page: 0, pageSize: 5 },
            },
          }}
          pageSizeOptions={[5, 10, 15]}
        />
      </Box>

      <Dialog open={dialog.open} onClose={handleCancelDelete}>
        <DialogTitle>Confirm Delete</DialogTitle>
        <DialogContent>
          Are you sure you want to delete this record?
        </DialogContent>
        <DialogActions>
          <Button onClick={handleCancelDelete} color="primary">
            Cancel
          </Button>
          <Button onClick={handleConfirmDelete} color="error">
            Delete
          </Button>
        </DialogActions>
      </Dialog>
      <SnackBar
        open={snackbar.open}
        onClose={handleCloseSnackbar}
        message={snackbar.message}
        severity={snackbar.severity}
      />

    </>
  );
};

export default Listing
