import React, { useState } from 'react';
import Link from 'next/link';
import Image from 'next/image';
import { AppBar, Toolbar, Typography, IconButton, Drawer, List, ListItem, ListItemText, Hidden } from '@mui/material';
import MenuIcon from '@mui/icons-material/Menu';
import logo from '../public/logo.png';

const NavigationLinks = [
  { href: "/", label: "HOME" },
  { href: "/contact", label: "CONTACT" },
  { href: "/contactListing", label: "LISTING" },
];

const NavLink = ({ href, label, onClick }) => (
  <ListItem button component={Link} href={href} onClick={onClick}>
    <ListItemText primary={label} />
  </ListItem>
);

function NavBar() {
  const [drawerOpen, setDrawerOpen] = useState(false);

  const handleDrawerOpen = () => {
    setDrawerOpen(true);
  };

  const handleDrawerClose = () => {
    setDrawerOpen(false);
  };

  return (
    <AppBar position="sticky" className="navbar">
      <Toolbar>
        <Image src={logo} alt="logo" className="logo" width={200} height={45} />
        <Hidden mdUp>
          <Drawer anchor="left" open={drawerOpen} onClose={handleDrawerClose}>
            <List>
              {NavigationLinks.map((item, index) => (
                <NavLink key={index} href={item.href} label={item.label} onClick={handleDrawerClose} />
              ))}
            </List>
          </Drawer>
        </Hidden>

        <Hidden mdDown>
          {NavigationLinks.map((link, index) => (
            <Typography key={index}>
              <NavLink href={link.href} label={link.label} />
            </Typography>
          ))}
        </Hidden>
        
        <Hidden mdUp>
          <Typography component="div" className='menuButton' />
          <IconButton edge="end" color="inherit" onClick={handleDrawerOpen}>
            <MenuIcon />
          </IconButton>
        </Hidden>
      </Toolbar>
    </AppBar>
  );
}

export default NavBar;
