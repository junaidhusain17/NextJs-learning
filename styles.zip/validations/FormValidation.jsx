import * as yup from "yup";

const formSchema = yup.object().shape({
    firstName: yup
        .string()
        .required('First name is required')
        .matches(/^[a-zA-Z]+[a-zA-Z\s]*$/, 'Please enter only letters')
        .min(3, 'First name should be minimum 3 characters')
        .max(20, 'First name should be maximum 20 characters'),


    lastName: yup
        .string()
        .required('Last name is a required field')
        .matches(/^[a-zA-Z]+[a-zA-Z\s]*$/, 'Please enter only letters')
        .min(3, 'Minimum length is 3 characters')
        .max(20, 'Maximum length is 20 characters'),



    email: yup
        .string()
        .required('Email is a required field')
        .matches(/^[a-zA-Z0-9._%+-]+@gmail\.com$/, 'Please enter a valid email address')
        .max(35, 'Maximum length is 35 characters'),

    contactNo: yup
        .string()
        .required('Phone number is required')
        .matches(/^(92\d{10})$/, 'Invalid phone number must be 12 digits ')
        .max(12, 'Contact number should be 12 digits'),

    account: yup
        .string()
        .required('Account is a required field')
        .matches(/^\S[\w\s]*$/, 'Please enter a valid account number')
        .max(25, 'Maximum length is 25 characters'),


    company: yup
        .string()
        .required('Company is a required field')
        .max(25, 'Maximum length is 25 characters'),

    confirmation: yup
        .boolean()
        .oneOf([true], 'Please check the box'),

    country: yup
        .string()
        .required('Country is required field')
        .notOneOf(["default"], 'Country is required field')


});

export default formSchema;