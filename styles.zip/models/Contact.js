const mongoose = require('mongoose');

// Define a schema for your contact data
const contactSchema = new mongoose.Schema({
  firstName: {
    type: String,
    // required: true,
  },
  lastName: {
    type: String,
    // required: true,
  },
  email: {
    type: String,
    // required: true,
  },
  // contactNo: {
  //   type: String,
  //   required: true,
  // },
  // account: {
  //   type: String,
  //   required: true,
  // },
  // company: {
  //   type: String,
  //   required: true,
  // },
  // status: {
  //   type: String,
  //   enum: ['enable', 'disable'],
  //   required: true,
  // },
  // country: {
  //   type: String,
  //   required: true,
  // },
  // subject: String,
  // userType: String,
  // confirmation: Boolean,
});

// Create a Mongoose model based on the schema
const Contact = mongoose.models.Contact || mongoose.model('Contact', contactSchema);
export default Contact;
