import React from "react";
import { Box, Typography } from "@mui/material";
import Image from "next/image";
import home from "../public/home.jpeg";

const Home = () => {
  return (
    <Box align="center">
      <Typography variant="h4" margin={4}>
        WELCOME TO HOME PAGE
      </Typography>
      <Image src={home} alt="home" style={{ maxWidth: '100%' }}/>
    </Box>
  );
};

export default Home;
