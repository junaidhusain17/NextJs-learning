import React from 'react'
import Listing from '@/components/Listing'

const contactListing = () => {
  return (
    <Listing />
  )
}

export default contactListing