import connectToMongoDB from "@/lib/mongodb";
import Contact from "@/pages/contact";
import { NextResponse } from "next/server";

// Define the API route handler
export default async function handler(request, response) {
  try {
    // Connect to MongoDB
    await connectToMongoDB();

    // Create a new contact
    const contact = await Contact.create(request.body);

    // Send a success response with the created topic
    response.status(201).json({ success: true, data: contact });
  } catch (error) {
    // Handle errors
    console.error("Error creating contact:", error);
    return NextResponse.error("Internal Server Error", { status: 500 });
  }
}